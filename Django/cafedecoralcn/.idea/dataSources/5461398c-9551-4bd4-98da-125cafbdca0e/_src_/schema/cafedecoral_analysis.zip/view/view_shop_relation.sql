CREATE VIEW view_shop_relation AS
  SELECT
    `cafedecoral_analysis`.`shop_relation`.`id`         AS `id`,
    `cafedecoral_analysis`.`shop_relation`.`shopName`   AS `shopName`,
    `cafedecoral_analysis`.`shop_relation`.`shopAddr`   AS `shopAddr`,
    `cafedecoral_analysis`.`shop_relation`.`shopTelFix` AS `shopTelFix`,
    `cafedecoral_analysis`.`shop_relation`.`dp`         AS `dp`,
    `cafedecoral_analysis`.`shop_relation`.`o_r`        AS `o_r`,
    `cafedecoral_analysis`.`shop_relation`.`mfw`        AS `mfw`,
    `cafedecoral_analysis`.`shop_relation`.`ta`         AS `ta`,
    ((((CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`o_r` IS NOT NULL)
      THEN 1
        ELSE 0 END) + (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`mfw` IS NOT NULL)
      THEN 1
                       ELSE 0 END)) + (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`ta` IS NOT NULL)
      THEN 1
                                       ELSE 0 END)) +
     (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`dp` IS NOT NULL)
       THEN 1
      ELSE 0 END))                                      AS `num`
  FROM `cafedecoral_analysis`.`shop_relation`
  WHERE ((`cafedecoral_analysis`.`shop_relation`.`repeat_mark` = 0) OR
         (`cafedecoral_analysis`.`shop_relation`.`repeat_mark` = 10))
  ORDER BY ((((CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`o_r` IS NOT NULL)
    THEN 1
               ELSE 0 END) + (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`mfw` IS NOT NULL)
    THEN 1
                              ELSE 0 END)) + (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`ta` IS NOT NULL)
    THEN 1
                                              ELSE 0 END)) +
            (CASE WHEN (`cafedecoral_analysis`.`shop_relation`.`dp` IS NOT NULL)
              THEN 1
             ELSE 0 END)) DESC;
