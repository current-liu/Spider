CREATE VIEW maxims_analysis.view_shop_relation AS
  SELECT
    `maxims_analysis`.`shop_relation`.`id`                          AS `id`,
    `maxims_analysis`.`shop_relation`.`shopName`                    AS `shopName`,
    `maxims_analysis`.`shop_relation`.`shopAddr`                    AS `shopAddr`,
    `maxims_analysis`.`shop_relation`.`shopTelFix`                  AS `shopTelFix`,
    `maxims_analysis`.`shop_relation`.`dp`                          AS `dp`,
    `maxims_analysis`.`shop_relation`.`o_r`                         AS `o_r`,
    `maxims_analysis`.`shop_relation`.`mfw`                         AS `mfw`,
    `maxims_analysis`.`shop_relation`.`ta`                          AS `ta`,
    ((((CASE WHEN (`maxims_analysis`.`shop_relation`.`o_r` IS NOT NULL)
      THEN 1
        ELSE 0 END) + (CASE WHEN (`maxims_analysis`.`shop_relation`.`mfw` IS NOT NULL)
      THEN 1
                       ELSE 0 END)) + (CASE WHEN (`maxims_analysis`.`shop_relation`.`ta` IS NOT NULL)
      THEN 1
                                       ELSE 0 END)) + (CASE WHEN (`maxims_analysis`.`shop_relation`.`dp` IS NOT NULL)
      THEN 1
                                                       ELSE 0 END)) AS `num`
  FROM `maxims_analysis`.`shop_relation`
  WHERE
    ((`maxims_analysis`.`shop_relation`.`repeat_mark` = 0) OR (`maxims_analysis`.`shop_relation`.`repeat_mark` = 10))
  ORDER BY ((((CASE WHEN (`maxims_analysis`.`shop_relation`.`o_r` IS NOT NULL)
    THEN 1
               ELSE 0 END) + (CASE WHEN (`maxims_analysis`.`shop_relation`.`mfw` IS NOT NULL)
    THEN 1
                              ELSE 0 END)) + (CASE WHEN (`maxims_analysis`.`shop_relation`.`ta` IS NOT NULL)
    THEN 1
                                              ELSE 0 END)) +
            (CASE WHEN (`maxims_analysis`.`shop_relation`.`dp` IS NOT NULL)
              THEN 1
             ELSE 0 END)) DESC;
