CREATE VIEW maxims_analysis.view_mfwcity AS
  SELECT
    `d`.`memberId` AS `memberId`,
    `d`.`location` AS `location`,
    `c`.`privince` AS `privince`
  FROM (`maxims_analysis`.`users_mfwmember` `d`
    JOIN `maxims_analysis`.`city` `c`)
  WHERE ((`d`.`location` = `c`.`city`) AND (`d`.`location` <> ' '));
