CREATE VIEW maxims_analysis.view_dpcity AS
  SELECT
    `d`.`memberId` AS `memberId`,
    `d`.`location` AS `location`,
    `c`.`privince` AS `privince`
  FROM (`maxims_analysis`.`users_dpmember` `d`
    JOIN `maxims_analysis`.`city` `c`)
  WHERE (`d`.`location` = `c`.`city`);
