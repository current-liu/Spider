CREATE VIEW maxims_analysis.view_dpreview AS
  SELECT
    `u`.`name`           AS `name`,
    `r`.`memberId`       AS `memberId`,
    `r`.`content`        AS `content`,
    left(`r`.`time`, 10) AS `time`,
    `r`.`taste`          AS `taste`,
    `r`.`environment`    AS `environment`,
    `r`.`likes`          AS `likes`,
    `r`.`reply`          AS `reply`,
    `u`.`pic`            AS `pic`
  FROM (`maxims_analysis`.`reviews_dpreview` `r`
    JOIN `maxims_analysis`.`users_dpmember` `u` ON ((`r`.`memberId` = `u`.`memberId`)));
