CREATE VIEW cafedecoral_analysis.view_orreview AS
  SELECT
    `r`.`memberName`     AS `memberName`,
    `r`.`memberId`       AS `memberId`,
    `r`.`title`          AS `title`,
    `r`.`content`        AS `content`,
    left(`r`.`time`, 10) AS `time`,
    `r`.`taste`          AS `taste`,
    `r`.`environment`    AS `environment`,
    `r`.`services`       AS `services`,
    `r`.`health`         AS `health`,
    `u`.`pic`            AS `pic`
  FROM (`cafedecoral_analysis`.`reviews_orreview` `r`
    JOIN `cafedecoral_analysis`.`users_ormember` `u` ON ((`r`.`memberId` = `u`.`memberId`)));
