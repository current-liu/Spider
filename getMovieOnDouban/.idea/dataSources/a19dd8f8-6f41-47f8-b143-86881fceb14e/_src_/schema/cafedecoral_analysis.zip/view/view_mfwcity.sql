CREATE VIEW cafedecoral_analysis.view_mfwcity AS
  SELECT
    `d`.`memberId` AS `memberId`,
    `d`.`location` AS `location`,
    `c`.`privince` AS `privince`
  FROM `cafedecoral_analysis`.`users_mfwmember` `d`
    JOIN `cafedecoral_analysis`.`city` `c`
  WHERE ((`d`.`location` = `c`.`city`) AND (`d`.`location` <> ' '));
