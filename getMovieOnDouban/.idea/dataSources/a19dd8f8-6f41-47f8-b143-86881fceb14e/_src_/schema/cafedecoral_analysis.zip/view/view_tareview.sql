CREATE VIEW cafedecoral_analysis.view_tareview AS
  SELECT
    `r`.`memberId`       AS `memberId`,
    `r`.`memberName`     AS `memberName`,
    `r`.`title`          AS `title`,
    `r`.`content`        AS `content`,
    left(`r`.`time`, 10) AS `time`,
    `r`.`star`           AS `star`,
    `u`.`pic`            AS `pic`
  FROM (`cafedecoral_analysis`.`reviews_tareview` `r`
    JOIN `cafedecoral_analysis`.`users_tamember` `u` ON ((`r`.`memberName` = `u`.`name`)));
