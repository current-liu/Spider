CREATE VIEW cafedecoral_analysis.view_mfwreview AS
  SELECT
    `r`.`memberId`       AS `memberId`,
    `u`.`name`           AS `name`,
    `r`.`content`        AS `content`,
    left(`r`.`time`, 10) AS `time`,
    `r`.`star`           AS `star`,
    `r`.`likes`          AS `likes`,
    `u`.`pic`            AS `pic`
  FROM (`cafedecoral_analysis`.`reviews_mfwreview` `r`
    JOIN `cafedecoral_analysis`.`users_mfwmember` `u` ON ((`r`.`memberId` = `u`.`memberId`)));
