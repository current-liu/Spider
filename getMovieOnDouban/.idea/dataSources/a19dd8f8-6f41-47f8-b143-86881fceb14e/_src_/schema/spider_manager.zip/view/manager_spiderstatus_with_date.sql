CREATE VIEW spider_manager.manager_spiderstatus_with_date AS
  SELECT
    `ss`.`id`                                 AS `id`,
    `ss`.`status`                             AS `status`,
    `ss`.`log`                                AS `log`,
    date_format(`ss`.`edit_time`, '%Y-%m-%d') AS `edit_date`,
    extract(YEAR FROM `ss`.`edit_time`)       AS `edit_year`,
    extract(MONTH FROM `ss`.`edit_time`)      AS `edit_month`,
    extract(HOUR FROM `ss`.`edit_time`)       AS `edit_hour`,
    `ss`.`spider_id`                          AS `spider_id`,
    `ss`.`operation_time`                     AS `operation_time`,
    `s`.`type`                                AS `type`
  FROM (`spider_manager`.`manager_spiderstatus` `ss`
    JOIN `spider_manager`.`manager_spider` `s` ON ((`ss`.`spider_id` = `s`.`id`)));
