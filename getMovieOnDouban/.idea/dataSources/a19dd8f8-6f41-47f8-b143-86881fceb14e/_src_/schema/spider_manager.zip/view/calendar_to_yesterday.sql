CREATE VIEW spider_manager.calendar_to_yesterday AS
  SELECT
    `spider_manager`.`calendar`.`id`       AS `id`,
    `spider_manager`.`calendar`.`datelist` AS `datelist`
  FROM `spider_manager`.`calendar`
  WHERE (`spider_manager`.`calendar`.`id` < (SELECT `spider_manager`.`calendar`.`id`
                                             FROM `spider_manager`.`calendar`
                                             WHERE (`spider_manager`.`calendar`.`datelist` = curdate())));
